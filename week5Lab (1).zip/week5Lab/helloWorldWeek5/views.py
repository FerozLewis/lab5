from django.shortcuts import render


def dispMessage(request):
    reqMessage = {'Message': "Hello World!"}
    return render(request, "dispMessage.html", reqMessage)
